import React from 'react'

const HelloWorld = () => {
    return (
        <div>HelloWorld</div>
    )
}

export default HelloWorld

